import copy
import numpy as np
class initial:
    def __init__(Eight_digits,stat):#进行初始化
        Eight_digits.pre=None
        Eight_digits.target=[[1,2,3],[8,0,4],[7,6,5]]#目标八数码的形式
        Eight_digits.stat=stat
        Eight_digits.find0()
        Eight_digits.update()
    def update(Eight_digits):#对启发函数的信息进行更新
        Eight_digits.fH()
        Eight_digits.fG()
        Eight_digits.fF()
    #G是深度，也就是走的步数
    def fG(Eight_digits):
        if(Eight_digits.pre!=None):
            Eight_digits.G=Eight_digits.pre.G+1
        else:
            Eight_digits.G=0

    def fH(Eight_digits):#计算到目标状态所需的步数
        Eight_digits.H=0
        for i in range(3):
            for j in range(3):
                targetX=Eight_digits.target[i][j]
                nowP=Eight_digits.findx(targetX)
                #曼哈顿距离之和
                Eight_digits.H+=abs(nowP[0]-i)+abs(nowP[1]-j)

    def fF(Eight_digits):#求得启发函数
        Eight_digits.F=Eight_digits.G+Eight_digits.H

    def Print(Eight_digits):#输出每一步的状态
        for i in range(3):
             print(Eight_digits.stat[i])
        print("F=",Eight_digits.F,"G=",Eight_digits.G,"H=",Eight_digits.H)
        print("-"*10)

    #查看找到的解是如何从头移动的
    def PrintAns(Eight_digits):
        ans=[]
        ans.append(Eight_digits)
        p=Eight_digits.pre
        while(p):
            ans.append(p)
            p=p.pre
        ans.reverse()
        for i in ans:
            i.Print()

    #找到数字x的位置
    def findx(Eight_digits,x):
        for i in range(3):
            if(x in Eight_digits.stat[i]):
                j=Eight_digits.stat[i].index(x)
                return [i,j]

    #找到0，也就是空白格的位置
    def find0(Eight_digits):
            Eight_digits.zero=Eight_digits.findx(0)

    #扩展当前状态，也就是上下左右移动。返回的是一个状态列表，也就是包含stat的列表
    def expand(Eight_digits):
        i=Eight_digits.zero[0]
        j=Eight_digits.zero[1]
        initialList=[]
        if(j==2 or j==1):
            initialList.append(Eight_digits.left())
        if(i==2 or i==1):
            initialList.append(Eight_digits.up())
        if(i==0 or i==1):
            initialList.append(Eight_digits.down())
        if(j==0 or j==1):
            initialList.append(Eight_digits.right())
        return initialList


    #deepcopy多维列表的复制，防止指针赋值将原列表改变
    #move只能移动行或列，即row和col必有一个为0
    #向某个方向移动
    def move(Eight_digits,row,col):
        newStat=copy.deepcopy(Eight_digits.stat)
        tmp=Eight_digits.stat[Eight_digits.zero[0]+row][Eight_digits.zero[1]+col]
        newStat[Eight_digits.zero[0]][Eight_digits.zero[1]]=tmp
        newStat[Eight_digits.zero[0]+row][Eight_digits.zero[1]+col]=0
        return newStat

    def up(Eight_digits):
        return Eight_digits.move(-1,0)

    def down(Eight_digits):
        return Eight_digits.move(1,0)

    def left(Eight_digits):
        return Eight_digits.move(0,-1)

    def right(Eight_digits):
        return Eight_digits.move(0,1)

#判断状态g是否在状态集合中，g是对象，gList是对象列表
#返回的结果是一个列表，第一个值是真假，如果是真则第二个值是g在gList中的位置索引
def isin(g,gList):
    gstat=g.stat
    statList=[]
    for i in gList:
        statList.append(i.stat)
    if(gstat in statList):
        res=[True,statList.index(gstat)]
    else:
        res=[False,0]
    return res

#计算逆序数之和
def SUM(nums):
    SUM=0
    for i in range(len(nums)):
        if(nums[i]!=0):
            for j in range(i):
                if(nums[j]>nums[i]):
                    SUM+=1
    return SUM

#根据逆序数之和判断所给八数码是否可解
def judge(src,target):
    SUM1=SUM(src)
    SUM2=SUM(target)
    if(SUM1%2==SUM2%2):
        return True
    else:
        return False

#Astar算法的函数
def Astar(startStat):
    #open和closed存的是initial对象
    open=[]
    closed=[]
    #初始化状态
    g=initial(startStat)
    #检查是否有解
    if(judge(startStat,g.target)!=True):
        print("所给八数码无解，请检查输入")
        exit(1)

    open.append(g)
    #time变量用于记录遍历次数
    time=0
    #当open表非空时进行遍历
    while(open):
        #根据启发函数值对open进行排序，默认升序
        open.sort(key=lambda G:G.F)
        #找出启发函数值最小的进行扩展
        minFStat=open[0]
        #检查是否找到解，如果找到则从头输出移动步骤
        if(minFStat.H==0):
            print("found and times:",time,"moves:",minFStat.G)
            minFStat.PrintAns()
            break

        #走到这里证明还没有找到解，对启发函数值最小的进行扩展
        open.pop(0)
        closed.append(minFStat)
        expandStats=minFStat.expand()
        #遍历扩展出来的状态
        for stat in expandStats:
            #将扩展出来的状态（二维列表）实例化为initial对象
            tmpG=initial(stat)
            #指针指向父节点
            tmpG.pre=minFStat
            #初始化时没有pre，所以G初始化时都是0
            #在设置pre之后应该更新G和F
            tmpG.update()
            #查看扩展出的状态是否已经存在与open或closed中
            findstat=isin(tmpG,open)
            findstat2=isin(tmpG,closed)
            #在closed中,判断是否更新
            if(findstat2[0]==True and tmpG.F<closed[findstat2[1]].F):
                closed[findstat2[1]]=tmpG
                open.append(tmpG)
                time+=1
            #在open中，判断是否更新
            if(findstat[0]==True and tmpG.F<open[findstat[1]].F):
                open[findstat[1]]=tmpG
                time+=1
            #tmpG状态不在open中，也不在closed中
            if(findstat[0]==False and findstat2[0]==False):
                open.append(tmpG)
                time+=1

stat=[[1, 6, 3], [2, 0 ,4], [7, 8, 5]]
Astar(stat)