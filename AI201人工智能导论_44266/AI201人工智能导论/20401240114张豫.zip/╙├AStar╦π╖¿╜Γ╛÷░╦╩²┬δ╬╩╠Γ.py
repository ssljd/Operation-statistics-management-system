import numpy as np
import copy
import time
from operator import itemgetter

goal = {}

def get_location(xl, n):  # 找到n对应的位置
    row_n = xl.shape[0]  # 行
    line_n = xl.shape[1]  # 列

    for i in range(row_n):
        for j in range(line_n):
            if n == xl[i][j]:
                return i, j


def get_actions(xl):  # 判断下一步能移动的位置
    row_n = xl.shape[0]
    line_n = xl.shape[1]

    (x, y) = get_location(xl, 0)  # 获取0的位置
    action = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    if x == 0:  # 0在第一行，不能上移
        action.remove((-1, 0))
    if y == 0:  # 不能左移
        action.remove((0, -1))
    if x == row_n - 1:  # 不能下移
        action.remove((1, 0))
    if y == line_n - 1:  # 不能右移
        action.remove((0, 1))

    return list(action)


def result(xl, action):  # 移动元素，做矩阵变换
    (x, y) = get_location(xl, 0)  # 获取0的位置
    (a, b) = action  # 获取可以移动的位置

    n = xl[x + a][y + b]  # 移动位置，交换元素
    s = copy.deepcopy(xl)
    s[x + a][y + b] = 0
    s[x][y] = n

    return s


def get_ManhattanDis(xl1, xl2):  # 计算曼哈顿距离 xl1是目标矩阵
    row_n = xl1.shape[0]
    line_n = xl1.shape[1]
    dis = 0

    for i in range(row_n):
        for j in range(line_n):
            if xl1[i][j] != xl2[i][j] and xl2[i][j] != 0:
                k, m = get_location(xl1, xl2[i][j])
                d = abs(i - k) + abs(j - m)
                dis += d

    return dis


def expand(p, actions, step):  # Actions是可以移动的方向, P是当前矩阵,step是所花的步数
    children = []
    for action in actions:
        child = {}
        child['parent'] = p
        child['xl'] = (result(p['xl'], action))
        child['dis'] = get_ManhattanDis(goal['xl'], child['xl'])
        child['step'] = step + 1
        child['dis'] = child['dis'] + child['step']  # 更新节点的代价值 f=g+h（step+child[dis]）
        child['action'] = get_actions(child['xl'])
        children.append(child)

    return children


def node_sort(nodelist):  # 对列表从大到小排序
    return sorted(nodelist, key=itemgetter('dis'), reverse=True)


# 获取输入
def get_input(n):
    A = []
    for i in range(n):
        temp = []
        p = []
        s = input()
        temp = s.split(' ')
        for t in temp:
            t = int(t)
            p.append(t)
        A.append(p)

    return A


def get_parent(node):
    q = {}
    q = node['parent']
    return q


def main():
    openlist = []  # open表
    close = []

    print('输入阶数')
    n = int(input())
    print("输入初始的矩阵")
    A = get_input(n)

    print("输入目标矩阵")
    B = get_input(n)

    # 存储步骤的文件
    resultfile = "a.txt"

    goal['xl'] = np.array(B)

    p = {}
    p['xl'] = np.array(A)
    p['dis'] = get_ManhattanDis(goal['xl'], p['xl'])
    p['step'] = 0
    p['action'] = get_actions(p['xl'])
    p['parent'] = {}

    if (p['xl'] == goal['xl']).all():
        return

    openlist.append(p)

    # start_CPU = time.clock()  #执行时间
    while openlist:

        children = []

        node = openlist.pop()  # 取出open表里的最后一个放入close表
        close.append(node)

        if (node['xl'] == goal['xl']).all():  # 检查当前矩阵和目标矩阵是否相同
            # end_CPU = time.clock()    #执行完成时间

            # 将步骤写入文件
            h = open(resultfile, 'w', encoding='utf-8', )
            h.write('Size of the search tree:' + str(len(openlist) + len(close)) + '\n')
            h.write('close：' + str(len(close)) + '\n')
            h.write('openlist：' + str(len(openlist)) + '\n')
            h.write('The path length:' + str(node['dis']) + '\n')
            h.write('The path of the solution: ' + '\n')
            i = 0
            way = []
            while close:
                way.append(node['xl'])
                node = get_parent(node)
                if (node['xl'] == p['xl']).all():
                    way.append(node['xl'])
                    break
            while way:
                i += 1
                h.write(str(i) + '\n')
                h.write(str(way.pop()) + '\n')
            h.close()
            f = open(resultfile, 'r', encoding='utf-8', )
            print(f.read())

            return

        children = expand(node, node['action'], node['step'])  # 如果不是目标矩阵, 扩展节点

        for child in children:
            f = False
            flag = False
            j = 0
            for i in range(len(openlist)):
                if (child['xl'] == openlist[i]['xl']).all():
                    j = i
                    flag = True
                    break
            for i in range(len(close)):  # 判断是否在close表
                if (child['xl'] == close[i]).all():
                    f = True
                    break
            if f == False and flag == False:
                openlist.append(child)

            elif flag == True:  # 比较代价值,保留较小的
                if child['dis'] < openlist[j]['dis']:
                    del openlist[j]
                    openlist.append(child)
        # 排序
        openlist = node_sort(openlist)


if __name__ == '__main__':
    main()
