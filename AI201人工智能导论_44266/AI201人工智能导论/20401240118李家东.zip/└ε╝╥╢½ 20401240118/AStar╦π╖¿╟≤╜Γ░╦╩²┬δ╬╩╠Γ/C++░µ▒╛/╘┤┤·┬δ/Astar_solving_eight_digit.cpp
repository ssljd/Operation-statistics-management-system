#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>

#define maxState 10000 //宏定义最大状态数量
#define N 3            //八数码行、列值
using namespace std;

/**
 * 函数名：isEqual
 * bref：判断总表a第n个表是否等于b
 * param：a: 数码表, b: 数码表, n
 * return：bool类型值
 **/
bool isEqual(int a[N][N][maxState], int b[N][N], int n)
{
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < N; j++)
                {
                        if (a[i][j][n] != b[i][j])
                                return false;
                }
        }
        return true;
}

/**
 * 函数名：isEqual
 * bref：判断a,b是否相等
 * param：a: 数码表, b: 数码表
 * return：bool类型值
 **/
bool isEqual(int a[N][N], int b[N][N])
{
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < N; j++)
                {
                        if (a[i][j] != b[i][j])
                        {
                                return false;
                        }
                }
        }
        return true;
}

/**
 * 函数名：evalute
 * bref：对当前八数码表与目标八数码表进行对比与评估
 * param：state: 数码表, target: 数码表
 * return：num
 **/
int evalute(int state[N][N], int target[N][N])
{
        int num = 0;
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < N; j++)
                {
                        if (state[i][j] != target[i][j])
                                num++;
                }
        }
        return num;
}

/**
 * 函数名：findBrack
 * bref：寻找空格点：0
 * param：a: 数码表, x: 行标号, y: 列标号
 * return：无
 **/
void findBrack(int a[N][N], int x, int y)
{
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < N; j++)
                {
                        if (a[i][j] == 0)
                        {
                                x = i;
                                y = j;
                                return;
                        }
                }
        }
}

/**
 * 函数名：move
 * bref：移动数码
 * param：a: 数码表, b: 数码表, dir: 移动数码方向
 * return：bool类型值
 **/
bool move(int a[N][N], int b[N][N], int dir)
{
        // 1:up 2:down 3:left 4:right
        int x = 0, y = 0;
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < N; j++)
                {
                        b[i][j] = a[i][j];
                        if (a[i][j] == 0)
                        {
                                x = i;
                                y = j;
                        }
                }
        }
        if (x == 0 && dir == 1)
                return false;
        if (x == N - 1 && dir == 2)
                return false;
        if (y == 0 && dir == 3)
                return false;
        if (y == N - 1 && dir == 4)
                return false;
        if (dir == 1) //上移
        {
                b[x - 1][y] = 0;
                b[x][y] = a[x - 1][y];
        }
        else if (dir == 2) //下移
        {
                b[x + 1][y] = 0;
                b[x][y] = a[x + 1][y];
        }
        else if (dir == 3) //左移
        {
                b[x][y - 1] = 0;
                b[x][y] = a[x][y - 1];
        }
        else if (dir == 4) //右移
        {
                b[x][y + 1] = 0;
                b[x][y] = a[x][y + 1];
        }
        else
                return false;
        return true;
}

/**
 * 函数名：statecpy
 * bref：复制总表的第n状态下的八数码表
 * param：a: 数码表, b: 数码表, n
 * return：无
 **/
void statecpy(int a[N][N][maxState], int b[N][N], int n)
{
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < N; j++)
                        a[i][j][n] = b[i][j];
        }
}

/**
 * 函数名：getState
 * bref：获取第状态n下的八数码表
 * param：a: 数码表, b: 数码表, n
 * return：无
 **/
void getState(int a[N][N][maxState], int b[N][N], int n)
{
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < N; j++)
                {
                        b[i][j] = a[i][j][n];
                }
        }
}

/**
 * 函数名：statecpy
 * bref：对单个八数码表进行复制
 * param：a: 数码表, b: 数码表, n
 * return：无
 **/
void statecpy(int a[N][N], int b[N][N])
{
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < N; j++)
                        a[i][j] = b[i][j];
        }
}

/**
 * 函数名：checkAdd
 * bref：检查总表里是否存在等于b的八数码表
 * param：a: 数码表, b: 数码表, n
 * return：i或-1
 **/
int checkAdd(int a[N][N][maxState], int b[N][N], int n)
{
        for (int i = 0; i < n; i++)
        {
                if (isEqual(a, b, i))
                        return i;
        }
        return -1;
}

/**
 * 函数名：Astar
 * bref：A*算法
 * param：a: 数码表, start: 数码表, target: 数码表, path: 路径数
 * return：Curid
 **/
int Astar(int a[N][N][maxState], int start[N][N], int target[N][N], int path[maxState])
{
        bool visited[maxState] = {false}; //访问标志
        int fitness[maxState] = {0};      //总代价(适应度)
        int passLen[maxState] = {0};      //移动的步数
        int curpos[N][N];                 //当前位置
        statecpy(curpos, start);
        int id = 0, Curid = 0; //id：步数编号；Curid：初始表到目标表的步数
        fitness[id] = evalute(curpos, target);
        statecpy(a, start, id++);
        while (!isEqual(curpos, target))
        {
                for (int i = 1; i < 5; i++) //向四周找方向
                {
                        int tmp[N][N] = {0}; //临时八数码表
                        if (move(curpos, tmp, i))
                        {
                                int state = checkAdd(a, tmp, id);
                                if (state == -1)
                                {
                                        path[id] = Curid;
                                        passLen[id] = passLen[Curid] + 1;
                                        fitness[id] = evalute(tmp, target) + passLen[id]; //f(n) = g(n) + h(n)
                                        statecpy(a, tmp, id++);
                                }
                                else
                                {
                                        int len = passLen[Curid] + 1, fit = evalute(tmp, target) + len;
                                        if (fit < fitness[state])
                                        {
                                                path[state] = Curid;
                                                passLen[state] = len;
                                                fitness[state] = fit;
                                                visited[state] = false;
                                        }
                                }
                        }
                }
                visited[Curid] = true;
                //找到适应度最小的值为下一个带搜索节点
                int minCur = -1;
                for (int i = 0; i < id; i++)
                {
                        if (!visited[i] && (minCur == -1 || fitness[i] < fitness[minCur]))
                                minCur = i;
                }
                Curid = minCur;
                getState(a, curpos, Curid);
                if (id == maxState)
                        return -1;
        }
        return Curid;
}

/**
 * 函数名：show
 * bref：显示八数码表
 * param：a: 数码表, n
 * return：无
 **/
void show(int a[N][N][maxState], int n)
{
        cout << "-------------------------------------------\n";
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < N; j++)
                        cout << a[i][j][n] << " ";
                cout << endl;
        }
}

/**
 * 函数名：calDe
 * bref：将九宫格转化为线性
 * param：a: 数码表
 * return：sum
 **/
int calDe(int a[N][N])
{
        int sum = 0;
        for (int i = 0; i < N * N; i++)
        {
                for (int j = i + 1; j < N * N; j++)
                {
                        int m, n, c, d;
                        m = i / N;
                        n = i % N;
                        c = j / N;
                        d = j % N;
                        if (a[c][d] == 0)
                                continue;
                        if (a[m][n] > a[c][d])
                                sum++;
                }
        }
        return sum;
}

/**
 * 函数名：autoGenerate
 * bref：随机自动生成八数码表
 * param：a: 数码表
 * return：无
 **/
void autoGenerate(int a[N][N])
{
        int maxMove = 1000; //最大移动次数
        srand((unsigned)time(NULL));
        int tmp[N][N];
        while (maxMove--)
        {
                int dir = rand() % 4 + 1;
                if (move(a, tmp, dir))
                        statecpy(a, tmp);
                // for (int i = 0; i < 3; i++)
                // {
                //         for (int j = 0; j < 3; j++)
                //         {
                //                 cout << a[i][j] << " ";
                //         }
                //         cout << endl;
                // }
                // cout << endl<<"--------------------------------------------\n";
        }
}

int main()
{
        int a[N][N][maxState] = {0};
        int start[N][N] = {1, 2, 3, 8, 0, 4, 7, 6, 5}; //初始化八数码表
        autoGenerate(start);
        for (int i = 0; i < 3; i++)
        {
                for (int j = 0; j < 3; j++)
                {
                        cout << start[i][j] << " ";
                }
                cout << endl;
        }
        //初始化目标表
        int target[N][N] = {1, 2, 3, 8, 0, 4, 7, 6, 5};
        //判断奇偶性是否一致，不一致，则无解；反之，则有解
        if (!(calDe(start) % 2 == calDe(target) % 2))
        {
                cout << "无解\n";
                return 0;
        }
        //初始化每一步下的八数码表拥有的路径数
        int path[maxState] = {0};

        int res = Astar(a, start, target, path);
        if (res == -1)
        {
                cout << "达到最大搜索能力\n";
                return 0;
        }
        int shortest[maxState] = {0}, j = 0;
        //搜索最短路径
        while (res != 0)
        {
                shortest[j++] = res;
                res = path[res];
        }
        cout << "第0步\n";
        //显示每一步下的八数码表
        show(a, 0);
        for (int i = j - 1; i >= 0; i--)
        {
                cout << "第" << j - i << "步\n";
                show(a, shortest[i]);
        }
        return 0;
}