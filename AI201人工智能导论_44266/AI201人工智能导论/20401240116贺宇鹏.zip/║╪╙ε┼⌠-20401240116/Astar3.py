import random

class gird:
    def __init__(self, list):
        self.list = list
    #输出八数码表
    def show(self, list):
        for j in range(len(list)):
            if j % 3 == 0:
                print('\t')
            print(list[j], end=' ')
        print('\t')  

    # 生成新的节点，并记录路径
    def create(self, array1, array2):
        p = array1[:]
        p.insert(0, array2)
        for i in closes:
            if i[0] == p[0]:
                return False
        opens.append(p)
        return True

    
    
    def run(self, str, index):
        if str == 'up':
            return index-3
        elif str == 'down':
            return index+3
        elif str == 'left':
            return index-1
        elif str == 'right':
            return index+1

    # 估计函数，与目标节点对比，返回当前数码与目标数码相同位置的个数
    def hx(self, current):
        count = 0
        goal = [1, 2, 3, 8, 0, 4, 7, 6, 5]
        for i in range(len(current)):
            if current[i] == goal[i]:
                count += 1
        return count

    def parity(self, array):
        num = 0
        for i in range(len(array) - 1):
            for j in range(i+1, len(array)):
                if array[i] == 0 or array[j] == 0:
                    continue
                if array[i] < array[j]:
                    num += 1
        return num%2


if __name__=='__main__':
    start = []
    start=[2,5,3,7,0,6,1,8,4]
    gird = gird(start)
    goal = [1, 2, 3, 8, 0, 4, 7, 6, 5]
    # 如果初态和终态的逆序奇偶性不同则无解
    if gird.parity(start) != gird.parity(goal):
        print('该始末状态的8数码无解')
        exit()
    opens = []
    closes = []
    creatpoint = serchpoint = step = 0
    opens.append([start])
    while 1:
        if start==goal:
            print('初始状态即为解')
            break
        if len(opens)==0:
            print('未找到解')
            break
        else:
            this = opens.pop(0)
            serchpoint += 1
            closes.append(this)
            if this[0] == goal:
                print('搜索成功')
                print('共创建{}个节点，共搜索{}个节点，'
                      '共{}步'.format(creatpoint, serchpoint, len(this)-1))
                for i in this[::-1]:
                    gird.show(i)
                exit()
            # 上移
            if this[0].index(0) > 2:
                node = this[0].copy()
                a = this[0].index(0)
                b = gird.run('up', a)
                node[a], node[b] = node[b], node[a]
                gird.create(this, node)
                creatpoint += 1
            # 下移
            if this[0].index(0) < 6:
                node = this[0].copy()
                a = this[0].index(0)
                b = gird.run('down', a)
                node[a], node[b] = node[b], node[a]
                gird.create(this, node)
                creatpoint += 1
            # 左移
            if this[0].index(0) != 0 and this[0].index(0) != 3 and this[0].index(0) != 6:
                node = this[0].copy()
                a = this[0].index(0)
                b = gird.run('left', a)
                node[a], node[b] = node[b], node[a]
                gird.create(this, node)
                creatpoint += 1
            # 右移
            if this[0].index(0) != 2 and this[0].index(0) != 5 and this[0].index(0) != 8:
                node = this[0].copy()
                a = this[0].index(0)
                b = gird.run('right', a)
                node[a], node[b] = node[b], node[a]
                gird.create(this, node)
                creatpoint += 1

            # 对与目标数码节点相同个数最多的数码节点放到open表最前面
            for i in range(len(opens)-1):
                for j in range(i+1, len(opens)):
                    if gird.hx(opens[i][0]) < gird.hx(opens[j][0]):
                        opens[i], opens[j] = opens[j], opens[i]